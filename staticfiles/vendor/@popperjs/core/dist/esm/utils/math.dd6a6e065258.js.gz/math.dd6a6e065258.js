export var max = Math.max;
export var min = Math.min;
export var round = Math.round;